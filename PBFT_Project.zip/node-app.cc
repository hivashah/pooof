#include "node-app.h"
#include "stdlib.h"
#include <numeric>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include "ns3/address-utils.h"
#include "ns3/address.h"
#include "ns3/double.h"
#include "ns3/inet-socket-address.h"
#include "ns3/inet6-socket-address.h"
#include "ns3/ipv4.h"
#include "ns3/log.h"
#include "ns3/node.h"
#include "ns3/packet.h"
#include "ns3/simulator.h"
#include "ns3/socket-factory.h"
#include "ns3/socket.h"
#include "ns3/tcp-socket-factory.h"
#include "ns3/trace-source-accessor.h"
#include "ns3/udp-socket-factory.h"

NS_LOG_COMPONENT_DEFINE("NodeApp");

namespace ns3 {

// Data structures to hold parsed data
struct Transaction {
    std::string transactionId;
    std::string sender;
    std::string receiver;
    double amount;
    std::string timestamp;
    std::string signature;
    int blockId;
    double reputation;
    int roundId;
    std::string validatorNode;
    double weight;
    std::string proposalId;
};

struct NodeStatus {
    int round;
    std::string nodeId;
    int stake;
    double reputation;
    std::string nodeRole;
    int voteCount;
};

std::vector<Transaction> transactions;
std::vector<NodeStatus> nodeStatuses;

// Helper functions to parse CSV files
std::vector<std::string> Split(const std::string &line, char delimiter) {
    std::vector<std::string> tokens;
    std::stringstream ss(line);
    std::string token;
    while (std::getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

void ParseTransactions(const std::string &filename) {
    std::ifstream file(filename);
    std::string line;
    bool isHeader = true;
    while (std::getline(file, line)) {
        if (isHeader) {
            isHeader = false;
            continue;
        }
        auto tokens = Split(line, ',');
        transactions.push_back({
            tokens[0], tokens[1], tokens[2], std::stod(tokens[3]), tokens[4],
            tokens[5], std::stoi(tokens[6]), std::stod(tokens[7]),
            std::stoi(tokens[8]), tokens[9], std::stod(tokens[10]), tokens[11]
        });
    }
}

void ParseNodeStatuses(const std::string &filename) {
    std::ifstream file(filename);
    std::string line;
    bool isHeader = true;
    while (std::getline(file, line)) {
        if (isHeader) {
            isHeader = false;
            continue;
        }
        auto tokens = Split(line, ',');
        nodeStatuses.push_back({
            std::stoi(tokens[0]), tokens[1], std::stoi(tokens[2]),
            std::stod(tokens[3]), tokens[4], std::stoi(tokens[5])
        });
    }
}

void NodeApp::StartApplication() {
    NS_LOG_INFO("Node application starting...");

    // Load datasets
    ParseTransactions("/mnt/data/Transactions_Dataset.csv");
    ParseNodeStatuses("/mnt/data/Node_Status_Dataset.csv");

    // Call existing initialization logic (if any)
    InitializeNode();

    // Simulate PBFT
    SimulatePBFT();
}

void NodeApp::SimulatePBFT() {
    NS_LOG_INFO("Starting PBFT simulation...");

    // Step 1: Pre-Prepare Phase
    for (const auto &transaction : transactions) {
        NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                     << " entering Pre-Prepare phase.");

        auto leaderNode = std::find_if(
            nodeStatuses.begin(), nodeStatuses.end(),
            [](const NodeStatus &node) { return node.nodeRole == "Leader"; });

        if (leaderNode == nodeStatuses.end()) {
            NS_LOG_WARN("No leader found for transaction " << transaction.transactionId);
            continue;
        }

        NS_LOG_INFO("Leader Node: " << leaderNode->nodeId
                     << " proposes Transaction ID: " << transaction.transactionId);

        // Broadcast proposal to all nodes
        for (const auto &node : nodeStatuses) {
            if (node.nodeId != leaderNode->nodeId) {
                NS_LOG_INFO("Leader Node: " << leaderNode->nodeId
                             << " sends Pre-Prepare message to Node: " << node.nodeId);
            }
        }

        // Step 2: Prepare Phase
        NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                     << " entering Prepare phase.");

        std::map<std::string, bool> prepareVotes;
        for (const auto &node : nodeStatuses) {
            // Simulate each node voting based on reputation or other criteria
            bool vote = node.reputation > 0.5;  // Example threshold
            prepareVotes[node.nodeId] = vote;

            NS_LOG_INFO("Node: " << node.nodeId
                         << " casts Prepare vote: " << (vote ? "Yes" : "No"));
        }

        // Check for majority agreement
        int prepareYesVotes = std::count_if(
            prepareVotes.begin(), prepareVotes.end(),
            [](const std::pair<std::string, bool> &vote) { return vote.second; });

        int requiredMajority = (nodeStatuses.size() * 2) / 3 + 1;

        if (prepareYesVotes >= requiredMajority) {
            NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                         << " achieved majority in Prepare phase.");
        } else {
            NS_LOG_WARN("Transaction ID: " << transaction.transactionId
                         << " failed in Prepare phase. Skipping to next transaction.");
            continue;
        }

        // Step 3: Commit Phase
        NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                     << " entering Commit phase.");

        std::map<std::string, bool> commitVotes;
        for (const auto &node : nodeStatuses) {
            // Simulate each node committing based on agreement
            bool commit = prepareVotes[node.nodeId];
            commitVotes[node.nodeId] = commit;

            NS_LOG_INFO("Node: " << node.nodeId
                         << " casts Commit vote: " << (commit ? "Yes" : "No"));
        }

        int commitYesVotes = std::count_if(
            commitVotes.begin(), commitVotes.end(),
            [](const std::pair<std::string, bool> &vote) { return vote.second; });

        if (commitYesVotes >= requiredMajority) {
            NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                         << " achieved majority in Commit phase.");
        } else {
            NS_LOG_WARN("Transaction ID: " << transaction.transactionId
                         << " failed in Commit phase. Skipping to next transaction.");
            continue;
        }

        // Step 4: Reply Phase
        NS_LOG_INFO("Transaction ID: " << transaction.transactionId
                     << " entering Reply phase.");
        NS_LOG_INFO("All nodes reached consensus for Transaction ID: "
                     << transaction.transactionId << ". Reply sent to client.");
    }

    NS_LOG_INFO("PBFT simulation completed.");
}

void NodeApp::ViewChange() {
    NS_LOG_INFO("Initiating View Change...");

    auto leaderNode = std::find_if(
        nodeStatuses.begin(), nodeStatuses.end(),
        [](const NodeStatus &node) { return node.nodeRole == "Leader"; });

    if (leaderNode == nodeStatuses.end()) {
        NS_LOG_WARN("No leader found to change view.");
        return;
    }

    // Rotate leader to the next node
    std::rotate(nodeStatuses.begin(), leaderNode, nodeStatuses.end());

    auto newLeader = std::find_if(
        nodeStatuses.begin(), nodeStatuses.end(),
        [](const NodeStatus &node) { return node.nodeRole == "Leader"; });

    if (newLeader != nodeStatuses.end()) {
        NS_LOG_INFO("New leader selected: " << newLeader->nodeId);
    } else {
        NS_LOG_WARN("Failed to select a new leader during View Change.");
    }
}

} // namespace ns3
