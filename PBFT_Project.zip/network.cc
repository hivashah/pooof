#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("BlockchainSimulator");

void StartSimulator() {
  const int totalNodes = 25;
  const int groupSize = 5;

  NodeContainer nodes;
  nodes.Create(totalNodes);

  // Install internet stack on all nodes
  InternetStackHelper stack;
  stack.Install(nodes);

  // Address helper
  Ipv4AddressHelper address;

  // Create intra-group connections
  PointToPointHelper intraGroupHelper;
  intraGroupHelper.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
  intraGroupHelper.SetChannelAttribute("Delay", StringValue("2ms"));

  // Create backbone connections
  PointToPointHelper backboneHelper;
  backboneHelper.SetDeviceAttribute("DataRate", StringValue("100Mbps"));
  backboneHelper.SetChannelAttribute("Delay", StringValue("5ms"));

  Ipv4InterfaceContainer interfaces;
  int networkBase = 1;

  // Connect nodes within each group
  for (int g = 0; g < totalNodes / groupSize; g++) {
    for (int i = 0; i < groupSize; i++) {
      for (int j = i + 1; j < groupSize; j++) {
        Ptr<Node> node1 = nodes.Get(g * groupSize + i);
        Ptr<Node> node2 = nodes.Get(g * groupSize + j);

        NetDeviceContainer devices = intraGroupHelper.Install(node1, node2);
        address.SetBase(
            Ipv4Address((std::to_string(networkBase) + ".0.0.0").c_str()),
            "255.255.255.0");
        interfaces.Add(address.Assign(devices));
        networkBase++;
      }
    }
  }

  // Connect backbone nodes
  std::vector<int> backboneNodes = {0, 5, 10, 15, 20};
  for (size_t i = 0; i < backboneNodes.size(); i++) {
    for (size_t j = i + 1; j < backboneNodes.size(); j++) {
      Ptr<Node> node1 = nodes.Get(backboneNodes[i]);
      Ptr<Node> node2 = nodes.Get(backboneNodes[j]);

      NetDeviceContainer devices = backboneHelper.Install(node1, node2);
      address.SetBase(
          Ipv4Address((std::to_string(networkBase) + ".0.0.0").c_str()),
          "255.255.255.0");
      interfaces.Add(address.Assign(devices));
      networkBase++;
    }
  }

  // Install a simple application on all nodes
  uint16_t port = 4000;
  for (int i = 0; i < totalNodes; i++) {
    OnOffHelper onOff("ns3::UdpSocketFactory",
                      InetSocketAddress(interfaces.GetAddress(1), port));
    onOff.SetConstantRate(DataRate("1Mbps"), 512);
    ApplicationContainer app = onOff.Install(nodes.Get(i));
    app.Start(Seconds(1.0));
    app.Stop(Seconds(10.0));
  }

  Simulator::Run();
  Simulator::Destroy();
}

int main(int argc, char *argv[]) {
  CommandLine cmd;
  cmd.Parse(argc, argv);

  Time::SetResolution(Time::NS);

  // Enable logging
  LogComponentEnable("BlockchainSimulator", LOG_LEVEL_INFO);

  // Start the simulator
  StartSimulator();

  return 0;
}
